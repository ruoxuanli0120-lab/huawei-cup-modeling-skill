# Core Mathematical Ideas

Record only recurring reasoning patterns actually encountered in study.

## Entry template

### Pattern

- Trigger:
- Core move:
- Encountered example:
- Related ideas:

