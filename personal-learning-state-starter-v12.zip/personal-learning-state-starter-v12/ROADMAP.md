# Current Roadmap

This roadmap is intentionally lightweight and should evolve with real coursework.

## Current course line

- Algebra
- Topology
- Foundations of Cryptography

## Supporting foundations

- Linear algebra
- Modular arithmetic / modular linear algebra
- Probability
- Number theory
- Complexity, indistinguishability, and reductions

## Long-term research line

Mathematical foundations -> modern cryptography -> lattice basics -> SIS/LWE -> ring/module lattice cryptography -> research topics.

For LWE, distinguish first conceptual readiness (modular linear algebra + probability/noise intuition) from deep/research readiness (lattices + indistinguishability + reductions). Do not treat the roadmap as a rigid syllabus; use course progress, prerequisite evidence, time, and learner state to choose the next step.
