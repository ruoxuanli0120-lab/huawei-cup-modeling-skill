# Learning State Directory

This directory is the learner-owned dynamic state used by the Adaptive Math Crypto Tutor.

- `CORE_PRINCIPLES.md`: highest-level learning/tutoring principles; keep stable unless the learner intentionally changes them.
- `student_state.json`: canonical compact knowledge state, including minimum vs deep prerequisites, optional learner-created insight nodes, high-value relationships, node-specific mastery dimensions, a small cognitive model, confidence, calibration notes, and next actions.
- `PROFILE.md`: stable human-readable learner profile and preferences.
- `ROADMAP.md`: lightweight course-to-research direction, not a rigid syllabus.
- `CORE_IDEAS.md`: broad recurring reasoning patterns; learner-specific conceptual insights belong in `student_state.json` as lightweight knowledge nodes so they can connect to other knowledge.
- `sessions.jsonl`: compact session summaries/deltas with evidence weight.
- `errors.jsonl`: only high-value recurring errors from evidence-worthy sessions.

Do not paste full raw chat histories into this directory. Keep it small and useful.

The tutor should normally read only the minimum state needed for the current topic. Unknown readiness is not weakness. Casual or otherwise low-evidence sessions should be logged without changing long-term mastery by default.

The cognitive layer is deliberately sparse: preserve only reusable insights, high-value relationships, and a few revisable hypotheses about how the learner builds understanding. Do not turn every thought into a node or every relation into an edge.
