# Learner Profile

- Stage: first-year mathematics master's student at Guangzhou University.
- Research area: cryptography and its applications.
- Long-term direction: build the mathematical and theoretical foundation for lattice cryptography research.
- Current courses: algebra, topology, foundations of cryptography.
- Default learning preference: understanding-first, adaptive use of intuition or application, minimum effective hints, and independent reasoning.
- Learning depth preference: go deep on structural/high-leverage knowledge; use lighter treatment when time is limited or the topic is only a tool.
- Calibration preference: mastery is revisable; casual, tired, distracted, or low-effort sessions should not be strong evidence of low mastery.
- Planning preference: identify one best next knowledge point or narrow subgoal from prerequisites, current coursework, leverage, time, and long-term research direction.
- Long-term objective: become increasingly able to understand, prove, transfer, and research without depending on AI for key reasoning steps.

See `CORE_PRINCIPLES.md` for the highest-level tutoring rules.
